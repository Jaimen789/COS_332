## How to run my application:

**NB commands only work on unix operating systems**

**Step 1:** pip3 install flask
**Step 2:** set FLASK_APP=app.py
**Step 3:** flask run
**Step 4:** Go to http://127.0.0.1:5000 on your browser.